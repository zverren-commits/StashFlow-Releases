// js/main.js (v57 - Fixed CEP panel reload. No blocking JSX startup I/O.)

(function () {
    'use strict';

    var csInterface = new CSInterface();
    var extensionPath = csInterface.getSystemPath(SystemPath.EXTENSION).replace(/\\/g, '/');
    var cacheFolder = extensionPath + '/cache';
    var LOCAL_STORAGE_KEY = 'stashflow_library_path_v2';
    var libraryPath = null;
    var allCompsData = [];
    var modalCallback = null;
    var isInitialized = false;
    var stashflowActivationToken = null;
    var userHwid = "";
    
    // Custom Stash Setup state
    var currentCompDuration = 0;
    var currentCompTime = 0;
    var currentCompFrameRate = 0;
    var currentCompName = '';
    var activeCategoryName = '';
    var lastStashTime = 0;

    // DOM references
    var selectCategory      = document.getElementById('category-select');
    var btnNewCategory      = document.getElementById('btn-new-category');
    var btnDeleteCategory   = document.getElementById('btn-delete-category');
    var btnRefresh          = document.getElementById('btn-refresh');
    var btnSetLibrary       = document.getElementById('btn-set-library');
    var btnOpenLibrary      = null; // Assigned dynamically to pathDisplay
    var galleryGrid         = document.getElementById('gallery-grid');
    var btnStash            = document.getElementById('btn-stash');
    var inputStashCategory  = document.getElementById('stash-category-input');
    var statusLabel         = document.getElementById('status-label');
    var modalOverlay        = document.getElementById('custom-modal-overlay');
    var modalTitle          = document.getElementById('modal-title');
    var modalMessage        = document.getElementById('modal-message');
    var modalInput          = document.getElementById('modal-input');
    var modalInputContainer = document.getElementById('modal-input-container');
    var modalBtnCancel      = document.getElementById('modal-btn-cancel');
    var modalBtnConfirm     = document.getElementById('modal-btn-confirm');
    var mainWrapper         = document.getElementById('main-wrapper');
    var customSelectEl      = document.getElementById('custom-category-select');
    var customSelectValue   = customSelectEl ? customSelectEl.querySelector('.custom-select-value') : null;
    var customSelectOptions = customSelectEl ? customSelectEl.querySelector('.custom-select-options') : null;
    var customSelectTrigger = customSelectEl ? customSelectEl.querySelector('.custom-select-trigger') : null;
    var loadingScreen       = document.getElementById('loading-screen');

    // Controls DOM references
    var btnViewGrid         = document.getElementById('btn-view-grid');
    var btnViewList         = document.getElementById('btn-view-list');
    var sliderCardSize      = document.getElementById('slider-card-size');
    var versionLabel        = document.getElementById('version-label');

    var scannedCategories   = [];

    // Setup and Manual Timeline DOM references
    var stashSetupOverlay  = document.getElementById('stash-setup-overlay');
    var stashBtnAuto       = document.getElementById('stash-btn-auto');
    var stashBtnManual     = document.getElementById('stash-btn-manual');
    var stashBtnCancelSetup = document.getElementById('stash-btn-cancel-setup');

    var stashManualOverlay = document.getElementById('stash-manual-overlay');
    var manualPreviewThumb = document.getElementById('manual-preview-thumb');
    var manualPreviewLoading = document.getElementById('manual-preview-loading');
    
    var sliderStaticTime   = document.getElementById('slider-static-time');
    var labelStaticTime    = document.getElementById('label-static-time');
    
    var sliderStartTime    = document.getElementById('slider-start-time');
    var labelStartTime     = document.getElementById('label-start-time');
    
    var sliderEndTime      = document.getElementById('slider-end-time');
    var labelEndTime       = document.getElementById('label-end-time');
    
    var manualBtnCancel    = document.getElementById('manual-btn-cancel');
    var manualBtnStash     = document.getElementById('manual-btn-stash');

    // Path display and Logo positioning
    var topBar = document.querySelector('.top-bar');
    var pathDisplay = document.createElement('span');
    pathDisplay.id = 'library-path-display-v52';
    pathDisplay.className = 'library-path-btn';

    if (topBar) {
        btnOpenLibrary = pathDisplay;

        var logoImg = document.createElement('img');
        logoImg.src = 'lastmvm_logo.png';
        logoImg.alt = 'StashFlow';
        logoImg.style.height = '30px';
        logoImg.style.marginRight = '4px';
        logoImg.style.opacity = '0.8';
        logoImg.style.flexShrink = '0';
        logoImg.style.cursor = 'pointer';
        logoImg.style.transition = 'opacity 0.2s ease, transform 0.2s ease';
        logoImg.addEventListener('mouseenter', function() {
            logoImg.style.opacity = '1';
            logoImg.style.transform = 'scale(1.08)';
        });
        logoImg.addEventListener('mouseleave', function() {
            logoImg.style.opacity = '0.8';
            logoImg.style.transform = 'scale(1)';
        });
        logoImg.addEventListener('click', function() {
            try {
                csInterface.openURLInDefaultBrowser("https://www.instagram.com/lastmvm");
            } catch(e) {
                console.error("Failed to open external URL:", e);
            }
        });
        topBar.appendChild(pathDisplay);
        topBar.appendChild(logoImg);
    }

    // ---- Utilities ----

    function setStatus(msg, isError) {
        if (!statusLabel) return;
        if (msg === 'Ready' || msg === 'Ready.' || msg === 'Library verified.' || msg === 'Library loaded.' || msg === 'Ready.') {
            statusLabel.innerHTML = '<span style="color:#30d158;margin-right:5px;font-size:11px;">●</span>Ready';
            statusLabel.style.color = 'var(--text-secondary)';
            return;
        }
        if (msg && msg.indexOf('Loaded') === 0 && msg.indexOf('templates') !== -1) {
            statusLabel.innerHTML = '<span style="color:#30d158;margin-right:5px;font-size:11px;">●</span>Ready';
            statusLabel.style.color = 'var(--text-secondary)';
            return;
        }
        statusLabel.textContent = msg;
        statusLabel.style.color = isError ? 'var(--btn-delete-text)' : 'var(--text-secondary)';
    }

    function logToServer(msg) {
        // NOTE: Do NOT call csInterface.evalScript here.
        // Calling evalScript inside an evalScript callback causes CEP bridge re-entry
        // which results in "No matching closing brace" ExtendScript errors.
        // Logging is done only at the JSX level via writeLogBuffer() inside each JSX function.
        try { setStatus('[LOG] ' + String(msg).substring(0, 80), false); } catch(e) {}
    }

    function updatePathDisplay() {
        if (!pathDisplay) return;
        pathDisplay.textContent = libraryPath ? libraryPath : '(no library set)';
        pathDisplay.title = libraryPath || '';
    }

    function callJsx(funcName, arg, callback) {
        if (stashflowActivationToken !== "StashFlowSecureTokenPassed_Beta_2026") {
            console.error("StashFlow Beta: Unauthenticated JSX request blocked.");
            setStatus('License activation required.', true);
            if (callback) callback(null);
            return;
        }
        var script;
        if (arg !== null && arg !== undefined) {
            script = funcName + '(' + JSON.stringify(arg) + ')';
        } else {
            script = funcName + '()';
        }
        csInterface.evalScript(script, function(result) {
            if (!callback) return;
            if (result === 'EvalScript error.' || result === undefined || result === null) {
                // Do NOT call logToServer or any evalScript here - would cause re-entry crash
                setStatus('JSX error: ' + funcName, true);
                callback(null);
                return;
            }
            if (typeof result === 'string' && result.length > 0 && (result.charAt(0) === '{' || result.charAt(0) === '[')) {
                try { result = JSON.parse(result); } catch(e) {}
            }
            callback(result);
        });
    }

    // ---- Custom Dropdown ----

    function updateCustomSelect(categories, selectedValue) {
        if (!customSelectOptions || !customSelectValue) return;
        customSelectOptions.innerHTML = '';
        categories.forEach(function(cat) {
            var opt = document.createElement('div');
            opt.className = 'custom-select-option' + (cat === selectedValue ? ' selected' : '');
            opt.textContent = cat;
            opt.dataset.value = cat;
            
            // Drag and Drop sorting category listeners
            opt.setAttribute('draggable', 'true');
            
            opt.addEventListener('dragstart', function(e) {
                opt.classList.add('dragging');
                if (mainWrapper) mainWrapper.classList.add('category-dragging-active');
                if (customSelectEl) customSelectEl.classList.add('open');
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/plain', cat);
                e.stopPropagation();
            });

            opt.addEventListener('dragend', function(e) {
                opt.classList.remove('dragging');
                if (mainWrapper) mainWrapper.classList.remove('category-dragging-active');
                customSelectOptions.querySelectorAll('.custom-select-option').forEach(function(o) {
                    o.classList.remove('drag-over');
                });
                e.stopPropagation();
                
                var optionElements = Array.from(customSelectOptions.querySelectorAll('.custom-select-option'));
                var newCatOrder = optionElements.map(function(el) {
                    return el.dataset.value;
                }).filter(Boolean);
                
                window.localStorage.setItem('stashflow_categories_order', JSON.stringify(newCatOrder));
                renderGallery();
                setTimeout(openCustomSelect, 50);
            });

            opt.addEventListener('dragover', function(e) {
                e.preventDefault();
                e.stopPropagation();
                e.dataTransfer.dropEffect = 'move';
                
                var draggingOpt = customSelectOptions.querySelector('.dragging');
                if (!draggingOpt || draggingOpt === opt) return;
                
                var box = opt.getBoundingClientRect();
                var centerVertical = box.top + box.height / 2;
                var insertBefore = e.clientY < centerVertical;
                
                if (insertBefore) {
                    customSelectOptions.insertBefore(draggingOpt, opt);
                } else {
                    customSelectOptions.insertBefore(draggingOpt, opt.nextSibling);
                }
            });

            opt.addEventListener('dragenter', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var draggingOpt = customSelectOptions.querySelector('.dragging');
                if (draggingOpt && draggingOpt !== opt) {
                    opt.classList.add('drag-over');
                }
            });

            opt.addEventListener('dragleave', function(e) {
                e.stopPropagation();
                opt.classList.remove('drag-over');
            });
            
            opt.addEventListener('click', function() {
                selectCategory.value = cat;
                customSelectValue.textContent = cat;
                customSelectOptions.querySelectorAll('.custom-select-option').forEach(function(o) {
                    o.classList.toggle('selected', o.dataset.value === cat);
                });
                closeCustomSelect();
                renderGallery();
            });
            customSelectOptions.appendChild(opt);
        });
        customSelectValue.textContent = selectedValue || (categories.length ? categories[0] : 'Select Category');
    }

    function openCustomSelect() {
        if (customSelectEl) customSelectEl.classList.add('open');
    }

    function closeCustomSelect() {
        if (customSelectEl) customSelectEl.classList.remove('open');
    }

    if (customSelectTrigger) {
        customSelectTrigger.addEventListener('click', function(e) {
            e.stopPropagation();
            if (customSelectEl.classList.contains('open')) {
                closeCustomSelect();
            } else {
                openCustomSelect();
            }
        });
    }

    if (customSelectEl) {
        customSelectEl.addEventListener('wheel', function(e) {
            // Lock wheel switching if dropdown options are open
            if (customSelectEl.classList.contains('open')) {
                return;
            }
            var options = selectCategory ? selectCategory.options : null;
            if (!options || options.length <= 1) return;
            
            e.preventDefault();
            var currentIndex = selectCategory.selectedIndex;
            var nextIndex = currentIndex;
            
            if (e.deltaY > 0) {
                nextIndex = (currentIndex + 1) % options.length;
            } else if (e.deltaY < 0) {
                nextIndex = (currentIndex - 1 + options.length) % options.length;
            }
            
            if (nextIndex !== currentIndex) {
                var newCat = options[nextIndex].value;
                selectCategory.value = newCat;
                if (customSelectValue) customSelectValue.textContent = newCat;
                if (customSelectOptions) {
                    customSelectOptions.querySelectorAll('.custom-select-option').forEach(function(o) {
                        o.classList.toggle('selected', o.dataset.value === newCat);
                    });
                }
                renderGallery();
            }
        }, { passive: false });
    }

    document.addEventListener('click', function() {
        closeCustomSelect();
    });

    // ---- Modal System ----

    function showModal(opts) {
        if (!modalOverlay) return;
        modalTitle.textContent   = opts.title   || 'Confirm';
        modalMessage.textContent = opts.message || '';
        if (opts.input) {
            modalInputContainer.classList.remove('hidden');
            modalInput.value = opts.defaultValue || '';
            modalInput.placeholder = opts.placeholder || '';
            setTimeout(function() { modalInput.focus(); }, 50);
        } else {
            modalInputContainer.classList.add('hidden');
        }
        modalBtnConfirm.textContent = opts.confirmText || 'Confirm';
        modalBtnConfirm.className = opts.confirmClass || 'btn-primary-confirm';
        
        if (opts.cancelText === '') {
            modalBtnCancel.style.display = 'none';
        } else {
            modalBtnCancel.style.display = 'inline-flex';
            modalBtnCancel.textContent  = opts.cancelText  || 'Cancel';
            modalBtnCancel.className    = opts.cancelClass  || '';
        }
        
        modalCallback = opts.onConfirm || null;
        modalOverlay.classList.remove('hidden');
        // Use setTimeout to allow display:none removal before triggering opacity transition
        setTimeout(function() { modalOverlay.classList.add('active'); }, 10);
        if (mainWrapper) mainWrapper.classList.add('modal-blur');
    }

    function hideModal() {
        if (modalOverlay) {
            modalOverlay.classList.remove('active');
            // Wait for CSS opacity transition (250ms) before hiding with display:none
            setTimeout(function() {
                if (modalOverlay && !modalOverlay.classList.contains('active')) {
                    modalOverlay.classList.add('hidden');
                }
                if (modalBtnCancel) {
                    modalBtnCancel.style.display = 'inline-flex';
                }
            }, 280);
        }
        if (mainWrapper) mainWrapper.classList.remove('modal-blur');
        modalCallback = null;
    }

    // ---- Stash Settings Overlay System ----

    function showStashSetup() {
        if (stashSetupOverlay) {
            stashSetupOverlay.classList.remove('hidden');
            setTimeout(function() { stashSetupOverlay.classList.add('active'); }, 10);
            if (mainWrapper) mainWrapper.classList.add('modal-blur');
        }
    }
    
    function hideStashSetup() {
        if (stashSetupOverlay) {
            stashSetupOverlay.classList.remove('active');
            setTimeout(function() {
                if (stashSetupOverlay && !stashSetupOverlay.classList.contains('active')) {
                    stashSetupOverlay.classList.add('hidden');
                }
            }, 280);
        }
        if (mainWrapper) mainWrapper.classList.remove('modal-blur');
    }

    function showStashManual() {
        if (stashManualOverlay) {
            stashManualOverlay.classList.remove('hidden');
            setTimeout(function() { stashManualOverlay.classList.add('active'); }, 10);
            if (mainWrapper) mainWrapper.classList.add('modal-blur');
        }
    }
    
    function hideStashManual() {
        if (stashManualOverlay) {
            stashManualOverlay.classList.remove('active');
            setTimeout(function() {
                if (stashManualOverlay && !stashManualOverlay.classList.contains('active')) {
                    stashManualOverlay.classList.add('hidden');
                }
            }, 280);
        }
        if (mainWrapper) mainWrapper.classList.remove('modal-blur');
        
        // Clean up temporary cache assets natively via Node.js
        try {
            var fs = require('fs');
            var pathA = cacheFolder + "/ae_stash_preview_a.png";
            var pathB = cacheFolder + "/ae_stash_preview_b.png";
            if (fs.existsSync(pathA)) fs.unlinkSync(pathA);
            if (fs.existsSync(pathB)) fs.unlinkSync(pathB);
        } catch(ex) {}
    }

    var isRendering = false;
    var pendingTime = null;
    var renderTimeout = null;
    var scrubToggle = false;

    function requestScrubPreview(time) {
        if (isRendering) {
            // Queue this timestamp to render next as soon as the current render finishes
            pendingTime = time;
            return;
        }

        isRendering = true;
        if (manualPreviewLoading) manualPreviewLoading.classList.remove('hidden');

        // Safety timeout: Reset lock after 2 seconds if JSX hangs
        if (renderTimeout) clearTimeout(renderTimeout);
        renderTimeout = setTimeout(function() {
            console.log("Render timeout hit for time: " + time);
            onRenderComplete(null);
        }, 2000);

        // Alternate suffixes to avoid file locks
        scrubToggle = !scrubToggle;
        var suffix = scrubToggle ? 'a' : 'b';

        callJsx('saveTempFrameCEP', { time: time, cacheFolder: cacheFolder, suffix: suffix }, function(result) {
            if (renderTimeout) {
                clearTimeout(renderTimeout);
                renderTimeout = null;
            }
            onRenderComplete(result);
        });
    }

    function onRenderComplete(result) {
        isRendering = false;

        // If another render request came in while we were busy, execute it immediately
        if (pendingTime !== null) {
            var nextTime = pendingTime;
            pendingTime = null;
            requestScrubPreview(nextTime);
        } else {
            if (manualPreviewLoading) manualPreviewLoading.classList.add('hidden');
            if (result && result.success && result.suffix) {
                // Set relative same-origin path to bypass Chromium local origin blocks
                manualPreviewThumb.src = "cache/ae_stash_preview_" + result.suffix + ".png?t=" + new Date().getTime();
            } else {
                console.error("StashFlow Error: Invalid JSX render response", result);
            }
        }
    }

    if (sliderStaticTime) {
        sliderStaticTime.addEventListener('input', function() {
            var val = parseFloat(sliderStaticTime.value);
            labelStaticTime.textContent = val.toFixed(2) + 's';
            
            // CTI Synchronization: instantly update AE playhead so the user sees it in the AE viewer
            callJsx('syncPlayheadTimeCEP', val);
            
            // Debounced preview frame rendering inside the panel
            requestScrubPreview(val);
        });
    }
    if (sliderStartTime) {
        sliderStartTime.addEventListener('input', function() {
            var val = parseFloat(sliderStartTime.value);
            labelStartTime.textContent = val.toFixed(2) + 's';
            if (parseFloat(sliderEndTime.value) < val) {
                sliderEndTime.value = val;
                labelEndTime.textContent = val.toFixed(2) + 's';
            }
        });
    }
    if (sliderEndTime) {
        sliderEndTime.addEventListener('input', function() {
            var val = parseFloat(sliderEndTime.value);
            labelEndTime.textContent = val.toFixed(2) + 's';
            if (parseFloat(sliderStartTime.value) > val) {
                sliderStartTime.value = val;
                labelStartTime.textContent = val.toFixed(2) + 's';
            }
        });
    }

    if (stashBtnCancelSetup) stashBtnCancelSetup.addEventListener('click', hideStashSetup);
    if (manualBtnCancel) manualBtnCancel.addEventListener('click', hideStashManual);

    if (stashBtnAuto) {
        stashBtnAuto.addEventListener('click', function() {
            hideStashSetup();
            executeStashProcess({});
        });
    }
    
    if (stashBtnManual) {
        stashBtnManual.addEventListener('click', function() {
            hideStashSetup();
            sliderStaticTime.min = 0;
            sliderStaticTime.max = currentCompDuration;
            sliderStaticTime.value = currentCompTime;
            labelStaticTime.textContent = currentCompTime.toFixed(2) + 's';
            
            sliderStartTime.min = 0;
            sliderStartTime.max = currentCompDuration;
            sliderStartTime.value = 0;
            labelStartTime.textContent = '0.00s';
            
            sliderEndTime.min = 0;
            sliderEndTime.max = currentCompDuration;
            sliderEndTime.value = currentCompDuration;
            labelEndTime.textContent = currentCompDuration.toFixed(2) + 's';
            
            manualPreviewThumb.src = '';
            showStashManual();
            requestScrubPreview(currentCompTime);
        });
    }
    
    if (manualBtnStash) {
        manualBtnStash.addEventListener('click', function() {
            var sTime = parseFloat(sliderStaticTime.value);
            var rStart = parseFloat(sliderStartTime.value);
            var rEnd = parseFloat(sliderEndTime.value);
            hideStashManual();
            executeStashProcess({
                staticTime: sTime,
                rangeStart: rStart,
                rangeEnd: rEnd
            });
        });
    }

    if (modalBtnCancel)  modalBtnCancel.addEventListener('click', hideModal);
    if (modalBtnConfirm) modalBtnConfirm.addEventListener('click', function() {
        if (modalCallback) {
            var val = modalInputContainer && !modalInputContainer.classList.contains('hidden') ? modalInput.value.trim() : null;
            modalCallback(val);
        }
        hideModal();
    });

    if (modalOverlay) {
        modalOverlay.addEventListener('click', function(e) {
            if (e.target === modalOverlay) hideModal();
        });
    }

    // ---- Gallery Rendering ----

    function renderGallery() {
        if (stashflowActivationToken !== "StashFlowSecureTokenPassed_Beta_2026") {
            if (galleryGrid) galleryGrid.innerHTML = '<div style="color: #ff3b30; padding: 20px; text-align: center; font-weight: bold;">Authentication Required</div>';
            return;
        }
        if (!galleryGrid) return;
        galleryGrid.innerHTML = '';
        if (!libraryPath) {
            galleryGrid.innerHTML = '<div class="no-library-overlay"><p>Set Library folder first to load templates.</p></div>';
            return;
        }

        // Build unique sorted category list (ES5 compatible)
        var categories = [];
        if (Array.isArray(scannedCategories)) {
            scannedCategories.forEach(function(cat) {
                if (cat && categories.indexOf(cat) === -1) {
                    categories.push(cat);
                }
            });
        }
        if (Array.isArray(allCompsData)) {
            allCompsData.forEach(function(comp) {
                if (comp.category && categories.indexOf(comp.category) === -1) {
                    categories.push(comp.category);
                }
            });
        }
        // Sort categories according to custom category order in localStorage
        var savedCategoriesOrderRaw = window.localStorage.getItem('stashflow_categories_order');
        if (savedCategoriesOrderRaw) {
            try {
                var catOrder = JSON.parse(savedCategoriesOrderRaw);
                if (Array.isArray(catOrder) && catOrder.length > 0) {
                    categories.sort(function(a, b) {
                        var idxA = catOrder.indexOf(a);
                        var idxB = catOrder.indexOf(b);
                        if (idxA === -1 && idxB === -1) return a.localeCompare(b);
                        if (idxA === -1) return 1;
                        if (idxB === -1) return -1;
                        return idxA - idxB;
                    });
                } else {
                    categories.sort();
                }
            } catch(e) {
                categories.sort();
            }
        } else {
            categories.sort();
        }

        var currentCategory = selectCategory.value;
        selectCategory.innerHTML = '';
        categories.forEach(function(cat) {
            var option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            selectCategory.appendChild(option);
        });

        var hasCurrent = categories.indexOf(currentCategory) !== -1;
        if (hasCurrent) {
            selectCategory.value = currentCategory;
        } else if (categories.length > 0) {
            selectCategory.value = categories[0];
        }

        var selectedCategory = selectCategory.value;
        updateCustomSelect(categories, selectedCategory);

        if (!allCompsData || !Array.isArray(allCompsData) || allCompsData.length === 0) {
            galleryGrid.innerHTML = '<p class="empty-message">No templates found. Stash a composition to start.</p>';
            return;
        }

        var filteredComps = allCompsData.filter(function(comp) {
            return !selectedCategory || comp.category === selectedCategory;
        });

        if (filteredComps.length === 0 && selectedCategory) {
            galleryGrid.innerHTML = '<p class="empty-message">Category "' + selectedCategory + '" is empty.</p>';
            return;
        }

        // Retrieve custom sort order from localStorage
        var savedSortOrderRaw = window.localStorage.getItem('stashflow_sort_order_' + selectedCategory);
        if (savedSortOrderRaw) {
            try {
                var orderIds = JSON.parse(savedSortOrderRaw);
                if (Array.isArray(orderIds) && orderIds.length > 0) {
                    filteredComps.sort(function(a, b) {
                        var idxA = orderIds.indexOf(a.uniqueId);
                        var idxB = orderIds.indexOf(b.uniqueId);
                        if (idxA === -1 && idxB === -1) return 0;
                        if (idxA === -1) return 1;
                        if (idxB === -1) return -1;
                        return idxA - idxB;
                    });
                }
            } catch(e) {
                console.error("Failed to parse sort order:", e);
            }
        }

        filteredComps.forEach(function(comp) {
            var card = document.createElement('div');
            card.className = 'card';
            card.dataset.uniqueId = comp.uniqueId;
            
            // Drag and Drop sorting event listeners
            card.setAttribute('draggable', 'true');
            
            card.addEventListener('dragstart', function(e) {
                card.classList.add('dragging');
                if (galleryGrid) galleryGrid.classList.add('dragging-active');
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/plain', comp.uniqueId);
            });

            card.addEventListener('dragend', function() {
                card.classList.remove('dragging');
                if (galleryGrid) galleryGrid.classList.remove('dragging-active');
                galleryGrid.querySelectorAll('.card').forEach(function(c) {
                    c.classList.remove('drag-over');
                });
                saveCurrentSortOrder(selectedCategory);
            });

            card.addEventListener('dragover', function(e) {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                var draggingCard = galleryGrid.querySelector('.dragging');
                if (!draggingCard || draggingCard === card) return;
                
                var box = card.getBoundingClientRect();
                var centerHorizontal = box.left + box.width / 2;
                var centerVertical = box.top + box.height / 2;
                var isListView = galleryGrid.classList.contains('list-view');
                var insertBefore = false;
                
                if (isListView) {
                    insertBefore = e.clientY < centerVertical;
                } else {
                    insertBefore = e.clientX < centerHorizontal || e.clientY < box.top + box.height * 0.3;
                }
                
                if (insertBefore) {
                    galleryGrid.insertBefore(draggingCard, card);
                } else {
                    galleryGrid.insertBefore(draggingCard, card.nextSibling);
                }
            });

            card.addEventListener('dragenter', function(e) {
                e.preventDefault();
                var draggingCard = galleryGrid.querySelector('.dragging');
                if (draggingCard && draggingCard !== card) {
                    card.classList.add('drag-over');
                }
            });

            card.addEventListener('dragleave', function() {
                card.classList.remove('drag-over');
            });

            var previewContainer = document.createElement('div');
            previewContainer.className = 'preview-container';

            var img = document.createElement('img');
            img.className = 'preview-image';
            var thumbSrc = comp.thumbPath ? ('file:///' + comp.thumbPath.replace(/\\/g, '/')) : null;

            if (thumbSrc) {
                img.src = thumbSrc;
                img.alt = comp.name;
            } else if (comp.previewFrames && comp.previewFrames.length > 0) {
                var midIdx = Math.floor(comp.previewFrames.length / 2);
                img.src = 'file:///' + comp.previewFrames[midIdx].replace(/\\/g, '/');
            }

            if (img.src) {
                img.onload = function() {
                    img.style.opacity = '1';
                };
                img.onerror = function() {
                    // Do not delete the image element, just log it. This prevents the hover loop from breaking if a frame is temporarily unreadable.
                    img.style.opacity = '0.3';
                };
                previewContainer.appendChild(img);
            } else {
                previewContainer.innerHTML = '<span>(no preview)</span>';
            }

            // Animated preview (multi-frame) on hover playing dynamically relative to composition duration
            if (comp.previewFrames && comp.previewFrames.length > 1) {
                var frames = comp.previewFrames.map(function(f) {
                    return 'file:///' + f.replace(/\\/g, '/');
                });
                
                // Calculate dynamic frame time to match composition length, capped to 12-15 FPS (66ms - 83ms) for smoothness
                var duration = parseFloat(comp.duration) || 3.0;
                var msPerFrame = Math.round((duration * 1000) / frames.length);
                if (msPerFrame < 66) msPerFrame = 66;   // Max 15 FPS
                if (msPerFrame > 83) msPerFrame = 83;   // Min 12 FPS

                frames.forEach(function(src) { var p = new Image(); p.src = src; });

                var progressBar = document.createElement('div');
                progressBar.className = 'preview-progress-bar';
                progressBar.style.transition = 'width ' + (msPerFrame / 1000) + 's linear';
                previewContainer.appendChild(progressBar);

                var playOverlay = document.createElement('div');
                playOverlay.className = 'preview-play-overlay';
                playOverlay.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>';
                previewContainer.appendChild(playOverlay);

                var intervalId = null;
                var frameIdx = 0;
                var isHovered = false;

                (function(localImg, localFrames, localProgress, localPlay) {
                    card.addEventListener('mouseenter', function() {
                        isHovered = true;
                        frameIdx = 0;
                        localPlay.classList.add('playing');
                        if (intervalId) clearInterval(intervalId);
                        
                        intervalId = setInterval(function() {
                            if (!isHovered) return;
                            frameIdx = (frameIdx + 1) % localFrames.length;
                            localImg.src = localFrames[frameIdx];
                            localProgress.style.width = (((frameIdx + 1) / localFrames.length) * 100) + '%';
                        }, msPerFrame);
                    });

                    card.addEventListener('mouseleave', function() {
                        isHovered = false;
                        if (intervalId) { clearInterval(intervalId); intervalId = null; }
                        localPlay.classList.remove('playing');
                        localImg.src = thumbSrc || localFrames[0];
                        localProgress.style.width = '0%';
                    });
                }(img, frames, progressBar, playOverlay));
            }

            var infoCol = document.createElement('div');
            infoCol.className = 'card-info-col';

            var titleRow = document.createElement('div');
            titleRow.className = 'card-title-row';

            var title = document.createElement('span');
            title.className = 'card-title';
            title.textContent = comp.name;

            var btnEdit = document.createElement('button');
            btnEdit.className = 'btn-edit-title';
            btnEdit.title = 'Rename';
            btnEdit.dataset.id = comp.uniqueId;
            btnEdit.dataset.category = comp.category;
            btnEdit.dataset.name = comp.name;
            btnEdit.innerHTML = '<svg viewBox="0 0 24 24" width="10" height="10"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>';

            titleRow.appendChild(title);
            titleRow.appendChild(btnEdit);

            var metaText = '';
            if (comp.width && comp.height) {
                metaText += comp.width + 'x' + comp.height;
            }
            if (comp.previewFrames && comp.previewFrames.length > 0) {
                var fps = comp.previewFPS || 12;
                var framesLen = comp.previewFrames.length;
                var durationSec = framesLen / fps;
                metaText += (metaText ? ' | ' : '') + durationSec.toFixed(1) + 's';
            }
            if (!metaText) metaText = 'Template';

            var metaSpan = document.createElement('span');
            metaSpan.className = 'card-meta';
            metaSpan.textContent = metaText;

            infoCol.appendChild(titleRow);
            infoCol.appendChild(metaSpan);

            var actionContainer = document.createElement('div');
            actionContainer.className = 'card-actions';

            var btnImport = document.createElement('button');
            btnImport.className = 'btn-import';
            btnImport.textContent = 'Import';
            btnImport.dataset.aepPath = comp.aepPath;

            var btnDelete = document.createElement('button');
            btnDelete.className = 'btn-delete';
            btnDelete.textContent = 'Delete';
            btnDelete.dataset.category = comp.category;
            btnDelete.dataset.id = comp.uniqueId;
            btnDelete.dataset.name = comp.name;

            actionContainer.appendChild(btnImport);
            actionContainer.appendChild(btnDelete);

            card.appendChild(previewContainer);
            card.appendChild(infoCol);
            card.appendChild(actionContainer);
            galleryGrid.appendChild(card);
        });
    }

    function saveCurrentSortOrder(categoryName) {
        if (!galleryGrid || !categoryName) return;
        var cards = Array.from(galleryGrid.querySelectorAll('.card'));
        var orderIds = cards.map(function(card) {
            return card.dataset.uniqueId;
        }).filter(Boolean);
        window.localStorage.setItem('stashflow_sort_order_' + categoryName, JSON.stringify(orderIds));
    }

    // ---- Data Loading ----

    function refreshCompsList(cb, isSilent) {
        if (!isSilent) {
            if (loadingScreen) {
                loadingScreen.classList.remove('hidden');
            }
            if (galleryGrid) {
                galleryGrid.classList.add('hidden');
                galleryGrid.classList.remove('animate-show');
            }
        }

        if (!libraryPath) {
            setStatus('Library path not set.', true);
            allCompsData = [];
            renderGallery();
            if (selectCategory) selectCategory.innerHTML = '';
            if (loadingScreen) loadingScreen.classList.add('hidden');
            if (galleryGrid) galleryGrid.classList.remove('hidden');
            if (cb) cb();
            return;
        }
        
        if (!isSilent) {
            setStatus('Refreshing...', false);
        }
        
        callJsx('getStashedCompsCEP', libraryPath, function(result) {
            logToServer('refreshCompsList received result type: ' + typeof result);

            if (result === null || result === undefined) {
                if (!isSilent) setStatus('Received no data from JSX.', true);
                if (loadingScreen) loadingScreen.classList.add('hidden');
                if (galleryGrid) galleryGrid.classList.remove('hidden');
                if (cb) cb();
                return;
            }

            if (result && typeof result === 'object' && Array.isArray(result.templates)) {
                allCompsData = result.templates;
                scannedCategories = result.categories || [];
            } else if (Array.isArray(result)) {
                allCompsData = result;
                scannedCategories = [];
            } else if (typeof result === 'object' && result.error) {
                if (!isSilent) setStatus('Error: ' + result.error, true);
                logToServer('JSX returned error: ' + result.error);
                if (loadingScreen) loadingScreen.classList.add('hidden');
                if (galleryGrid) galleryGrid.classList.remove('hidden');
                if (cb) cb();
                return;
            } else {
                if (!isSilent) setStatus('Unexpected response from JSX.', true);
                logToServer('Unexpected result type: ' + typeof result + ' len: ' + (result ? String(result).length : 0));
                if (loadingScreen) loadingScreen.classList.add('hidden');
                if (galleryGrid) galleryGrid.classList.remove('hidden');
                if (cb) cb();
                return;
            }

            if (allCompsData.length === 0) {
                if (!isSilent) setStatus('No templates found.', false);
            } else {
                setStatus('Ready', false);
            }
            renderGallery();
            
            // Hide loading screen and trigger Apple fade-in animation if not silent
            if (loadingScreen) {
                loadingScreen.classList.add('hidden');
            }
            if (galleryGrid) {
                galleryGrid.classList.remove('hidden');
                if (!isSilent) {
                    galleryGrid.classList.add('animate-show');
                }
            }

            if (cb) cb();
        });
    }

    // ---- Button Handlers ----

    if (btnRefresh) {
        btnRefresh.addEventListener('click', function() {
            refreshCompsList();
        });
    }

    if (btnSetLibrary) {
        btnSetLibrary.addEventListener('click', function() {
            setStatus('Opening folder picker...', false);
            callJsx('selectLibraryFolderCEP', null, function(result) {
                if (result && typeof result === 'string' && result.length > 0) {
                    callJsx('checkAndConfirmFolderPathCEP', result, function(verified) {
                        if (verified && verified.exists && verified.confirmedPath) {
                            libraryPath = verified.confirmedPath;
                            callJsx('saveLibraryPathToConfigCEP', libraryPath, function() {});
                            updatePathDisplay();
                            refreshCompsList();
                        } else {
                            setStatus('Invalid folder selected.', true);
                        }
                    });
                } else {
                    setStatus('No folder selected.', false);
                }
            });
        });
    }

    if (btnOpenLibrary) {
        btnOpenLibrary.addEventListener('click', function() {
            if (!libraryPath) {
                if (btnSetLibrary) btnSetLibrary.click();
                return;
            }
            callJsx('openFolderCEP', libraryPath, function(result) {
                if (result && !result.success) setStatus('Could not open folder.', true);
            });
        });
    }

    if (btnNewCategory) {
        btnNewCategory.addEventListener('click', function() {
            if (!libraryPath) { setStatus('Set library first.', true); return; }
            showModal({
                title: 'New Category',
                message: 'Enter a name for the new category:',
                input: true,
                placeholder: 'e.g. Titles, VFX, Lower Thirds',
                confirmText: 'Create',
                onConfirm: function(val) {
                    if (!val) { setStatus('Category name cannot be empty.', true); return; }
                    callJsx('createCategoryCEP', { libraryPath: libraryPath, categoryName: encodeURIComponent(val) }, function(result) {
                        if (result && result.success) {
                            setStatus('Category "' + result.categoryName + '" created.', false);
                            refreshCompsList();
                            setTimeout(function() {
                                selectCategory.value = result.categoryName;
                                renderGallery();
                            }, 300);
                        } else {
                            setStatus(result && result.message ? result.message : 'Could not create category.', true);
                        }
                    });
                }
            });
        });
    }

    if (btnDeleteCategory) {
        btnDeleteCategory.addEventListener('click', function() {
            if (!libraryPath) { setStatus('Set library first.', true); return; }
            var currentCategory = selectCategory ? selectCategory.value : '';
            if (!currentCategory) { setStatus('Please select a category first.', true); return; }
            
            showModal({
                title: 'Delete Category',
                message: 'Delete category "' + currentCategory + '" and ALL its templates permanently? This CANNOT be undone!',
                confirmText: 'Delete Category',
                confirmClass: 'btn-delete-confirm',
                onConfirm: function() {
                    setStatus('Deleting category...', false);
                    callJsx('deleteCategoryCEP', { libraryPath: libraryPath, categoryName: encodeURIComponent(currentCategory) }, function(result) {
                        if (result && result.success) {
                            setStatus('Category deleted.', false);
                            if (selectCategory) selectCategory.value = '';
                            refreshCompsList();
                        } else {
                            setStatus(result && result.message ? result.message : 'Could not delete category.', true);
                        }
                    });
                }
            });
        });
    }

    function executeStashProcess(stashOpts) {
        setStatus('Stashing...', false);
        var params = {
            libraryPath: libraryPath,
            categoryName: encodeURIComponent(activeCategoryName)
        };
        if (stashOpts.staticTime !== undefined) {
            params.staticTime = stashOpts.staticTime;
            params.rangeStart = stashOpts.rangeStart;
            params.rangeEnd = stashOpts.rangeEnd;
        }
        if (stashOpts.useWorkArea !== undefined) {
            params.useWorkArea = stashOpts.useWorkArea;
        }
        
        callJsx('stashSelectedCompCEP', params, function(result) {
            if (result && result.success) {
                setStatus(result.message || 'Stashed!', false);
                if (inputStashCategory) inputStashCategory.value = '';
                lastStashTime = Date.now(); // lock focus scan
                
                setTimeout(function() {
                    refreshCompsList();
                }, 1000);
                
                setTimeout(function() {
                    if (result.categoryName) {
                        selectCategory.value = result.categoryName;
                        renderGallery();
                    }
                }, 1400);
            } else {
                setStatus(result && result.message ? result.message : 'Stash failed.', true);
            }
        });
    }

    if (btnStash) {
        btnStash.addEventListener('click', function() {
            if (!libraryPath) { setStatus('Set library first.', true); return; }
            var typedCategory = inputStashCategory ? inputStashCategory.value.trim() : '';
            var selectedCategory = selectCategory ? selectCategory.value : '';
            activeCategoryName = typedCategory || selectedCategory;

            if (!activeCategoryName) {
                setStatus('Select or type a category first.', true);
                return;
            }

            setStatus('Checking composition...', false);
            callJsx('getActiveCompDurationCEP', null, function(result) {
                if (result && result.success) {
                    currentCompDuration = result.duration;
                    currentCompTime = result.time;
                    currentCompFrameRate = result.frameRate;
                    currentCompName = result.name;
                    setStatus('Ready', false);
                    showStashSetup();
                } else {
                    setStatus('Ready', false);
                    showModal({
                        title: 'No Composition Selected',
                        message: 'Please select a composition in After Effects first.',
                        confirmText: 'OK',
                        cancelText: ''
                    });
                }
            });
        });
    }

    // Import & Delete via event delegation
    galleryGrid.addEventListener('click', function(e) {
        var target = e.target;

        if (target.classList.contains('btn-import')) {
            var aepPath = target.dataset.aepPath;
            if (!aepPath) { setStatus('No AEP path found.', true); return; }
            setStatus('Importing...', false);
            callJsx('importCompCEP', aepPath, function(result) {
                if (result && result.success) {
                    setStatus(result.message || 'Imported!', false);
                } else {
                    setStatus(result && result.message ? result.message : 'Import failed.', true);
                }
            });
        }

        if (target.classList.contains('btn-delete')) {
            var category = target.dataset.category;
            var uniqueId = target.dataset.id;
            var compName = target.dataset.name;
            showModal({
                title: 'Delete Template',
                message: 'Permanently delete "' + compName + '"? This cannot be undone.',
                confirmText: 'Delete',
                confirmClass: 'btn-delete-confirm',
                onConfirm: function() {
                    setStatus('Deleting...', false);
                    callJsx('deleteStashedCompCEP', { libraryPath: libraryPath, category: encodeURIComponent(category), uniqueId: uniqueId }, function(result) {
                        if (result && result.success) {
                            setStatus('Deleted "' + compName + '".', false);
                            refreshCompsList();
                        } else {
                            setStatus(result && result.message ? result.message : 'Delete failed.', true);
                        }
                    });
                }
            });
        }

        var editBtn = target.closest('.btn-edit-title');
        if (editBtn) {
            var uniqueId = editBtn.dataset.id;
            var category = editBtn.dataset.category;
            var compName = editBtn.dataset.name;
            showModal({
                title: 'Rename Template',
                message: 'Enter new name for "' + compName + '":',
                input: true,
                defaultValue: compName,
                placeholder: 'e.g. Lower Third Blue',
                confirmText: 'Rename',
                onConfirm: function(val) {
                    var newName = val ? val.trim() : '';
                    if (!newName) { setStatus('Name cannot be empty.', true); return; }
                    setStatus('Renaming...', false);
                    callJsx('renameStashedCompCEP', { libraryPath: libraryPath, category: encodeURIComponent(category), uniqueId: uniqueId, newName: newName }, function(result) {
                        if (result && result.success) {
                            setStatus('Renamed successfully!', false);
                            refreshCompsList();
                        } else {
                            setStatus(result && result.message ? result.message : 'Rename failed.', true);
                        }
                    });
                }
            });
        }
    });

    // ---- Init ----

    function init() {
        if (stashflowActivationToken !== "StashFlowSecureTokenPassed_Beta_2026") {
            setStatus('License activation required.', true);
            return;
        }
        setStatus('Initializing...', false);
        // Default starting point should be empty if not selected
        var defaultPath = window.localStorage.getItem(LOCAL_STORAGE_KEY) || '';

        // Wire up controls (Grid/List toggle, Card size slider)
        var savedSize = window.localStorage.getItem('stashflow_card_size') || '180';
        if (sliderCardSize) {
            sliderCardSize.value = savedSize;
            if (galleryGrid) galleryGrid.style.setProperty('--card-size', savedSize + 'px');
            sliderCardSize.addEventListener('input', function() {
                var sizeVal = sliderCardSize.value;
                if (galleryGrid) galleryGrid.style.setProperty('--card-size', sizeVal + 'px');
                window.localStorage.setItem('stashflow_card_size', sizeVal);
            });
        }

        var savedViewMode = window.localStorage.getItem('stashflow_view_mode') || 'grid';
        if (galleryGrid) {
            if (savedViewMode === 'list') {
                galleryGrid.classList.add('list-view');
                if (btnViewGrid) btnViewGrid.classList.remove('active');
                if (btnViewList) btnViewList.classList.add('active');
            } else {
                galleryGrid.classList.remove('list-view');
                if (btnViewGrid) btnViewGrid.classList.add('active');
                if (btnViewList) btnViewList.classList.remove('active');
            }
        }

        if (btnViewGrid) {
            btnViewGrid.addEventListener('click', function() {
                if (galleryGrid) galleryGrid.classList.remove('list-view');
                btnViewGrid.classList.add('active');
                if (btnViewList) btnViewList.classList.remove('active');
                window.localStorage.setItem('stashflow_view_mode', 'grid');
            });
        }
        if (btnViewList) {
            btnViewList.addEventListener('click', function() {
                if (galleryGrid) galleryGrid.classList.add('list-view');
                if (btnViewGrid) btnViewGrid.classList.remove('active');
                btnViewList.classList.add('active');
                window.localStorage.setItem('stashflow_view_mode', 'list');
            });
        }

        callJsx('getLibraryPathFromConfigCEP', null, function(pathResult) {
            var savedPath = (pathResult && typeof pathResult === 'string' && pathResult.length > 0)
                ? pathResult
                : defaultPath;

            // Pre-set libraryPath to savedPath so onPanelShown can scan even if verification below fails
            libraryPath = savedPath;
            updatePathDisplay();

            if (savedPath) {
                setStatus('Verifying library path...', false);
                callJsx('checkAndConfirmFolderPathCEP', savedPath, function(verified) {
                    if (verified && verified.exists && verified.confirmedPath) {
                        libraryPath = verified.confirmedPath;
                        setStatus('Library verified.', false);
                        updatePathDisplay();
                        
                        var retryCount = 0;
                        refreshCompsList(function() {
                            isInitialized = true;
                            // Self-healing retry if After Effects engine returned empty templates during startup lag
                            if (allCompsData.length === 0 && retryCount < 1) {
                                retryCount++;
                                setTimeout(function() {
                                    logToServer('Startup empty list self-healing retry...');
                                    refreshCompsList(null, true);
                                }, 2000);
                            }
                        });
                    } else {
                        // checkAndConfirmFolderPathCEP failed (maybe AE dialog blocked it)
                        // libraryPath is already set to savedPath - try scanning directly
                        setStatus('Verification failed. Trying to scan anyway...', false);
                        var retryCount2 = 0;
                        refreshCompsList(function() {
                            isInitialized = true;
                            if (allCompsData.length === 0 && retryCount2 < 1) {
                                retryCount2++;
                                setTimeout(function() {
                                    logToServer('Startup empty list self-healing retry...');
                                    refreshCompsList(null, true);
                                }, 2000);
                            }
                        });
                    }
                });
            } else {
                setStatus('Library path not set. Click the folder path to set library.', true);
                libraryPath = null;
                updatePathDisplay();
                renderGallery();
                isInitialized = true;
            }
        });

        // Theme handler
        var themeHandler = function() {
            try {
                var hostEnv = csInterface.getHostEnvironment();
                if (hostEnv && hostEnv.appSkinInfo && hostEnv.appSkinInfo.panelBackgroundColor && hostEnv.appSkinInfo.panelBackgroundColor.color) {
                    var bgColor = hostEnv.appSkinInfo.panelBackgroundColor.color;
                    var isLight = bgColor.red + bgColor.green + bgColor.blue > 382.5;
                    document.body.className = isLight ? 'theme-light' : 'theme-dark';
                } else {
                    document.body.className = 'theme-dark';
                }
            } catch(e) {
                document.body.className = 'theme-dark';
            }
        };
        csInterface.addEventListener(CSInterface.THEME_COLOR_CHANGED_EVENT, themeHandler);
        themeHandler();

        // ---- Auto-Updater Initialization ----
        if (typeof Updater !== 'undefined') {
            if (versionLabel) {
                versionLabel.textContent = 'v' + Updater.APP_VERSION;
            }
            setTimeout(function() {
                Updater.checkForUpdates(function(err, info) {
                    if (!err && info && info.available) {
                        if (versionLabel) {
                            versionLabel.classList.add('update-available-highlight');
                            versionLabel.title = 'New version v' + info.latest + ' is available! Click to update.';
                            versionLabel.style.cursor = 'pointer';
                        }
                    }
                });
            }, 3000); // 3-second delay to keep panel load lightweight
        }

        if (versionLabel) {
            versionLabel.addEventListener('click', function() {
                if (typeof Updater === 'undefined') return;
                if (!versionLabel.classList.contains('update-available-highlight') && versionLabel.textContent.indexOf('Restart') === -1) return;
                
                if (versionLabel.textContent.indexOf('Restart') !== -1) {
                    showModal({
                        title: 'Restart After Effects',
                        message: 'Please restart After Effects to complete the installation of the new version.',
                        confirmText: 'OK',
                        cancelText: ''
                    });
                    return;
                }
                
                var changelogHtml = Updater.buildChangelogHTML();
                var latestVer = Updater.getLatestVersion();
                showModal({
                    title: 'Update to v' + latestVer,
                    message: 'A new version of StashFlow is available. Review the changelog below:',
                    confirmText: 'Install Update',
                    onConfirm: function() {
                        setStatus('Downloading and installing update...', false);
                        versionLabel.style.pointerEvents = 'none';
                        versionLabel.textContent = 'Updating...';
                        if (mainWrapper) mainWrapper.classList.add('modal-blur');
                        
                        Updater.installUpdate(function(installErr, res) {
                            versionLabel.style.pointerEvents = 'auto';
                            if (mainWrapper) mainWrapper.classList.remove('modal-blur');
                            
                            if (installErr) {
                                setStatus('Update failed: ' + installErr, true);
                                versionLabel.textContent = 'Failed';
                                showModal({
                                    title: 'Update Failed',
                                    message: 'Error during update installation: ' + installErr,
                                    confirmText: 'OK',
                                    cancelText: ''
                                });
                            } else {
                                setStatus('Update complete! Please restart After Effects.', false);
                                versionLabel.classList.remove('update-available-highlight');
                                versionLabel.textContent = 'Restart AE';
                                versionLabel.style.background = 'rgba(48,209,88,0.15)';
                                versionLabel.style.borderColor = 'rgba(48,209,88,0.4)';
                                versionLabel.style.color = '#30d158';
                                showModal({
                                    title: 'Update Successful',
                                    message: 'StashFlow has been successfully updated to v' + latestVer + '! Please restart After Effects to load the new version.',
                                    confirmText: 'OK',
                                    cancelText: ''
                                });
                            }
                        });
                    }
                });
                
                // Inject the changelog list into the modal
                setTimeout(function() {
                    var msgEl = document.getElementById('modal-message');
                    if (msgEl) {
                        var wrapper = document.createElement('div');
                        wrapper.style.marginTop = '10px';
                        wrapper.innerHTML = changelogHtml;
                        msgEl.appendChild(wrapper);
                    }
                }, 50);
            });
        }
    }

    // ---- Node-Locked Licensing System (Motherboard HWID + 2-Device Limit) ----
    var userHwid = "";

    function getMotherboardHWID(callback) {
        try {
            if (typeof require !== 'undefined') {
                var exec = require('child_process').exec;
                exec('wmic csproduct get uuid', function(err, stdout, stderr) {
                    var uuid = "";
                    if (!err && stdout) {
                        var lines = stdout.split('\n');
                        if (lines.length > 1) {
                            uuid = lines[1].trim();
                        }
                    }
                    if (!uuid || uuid.indexOf("value") !== -1 || uuid.toLowerCase() === "to be filled by o.e.m.") {
                        uuid = require('os').hostname() + '-' + (process.env.USERNAME || process.env.USER || "user");
                    }
                    callback(uuid);
                });
            } else {
                throw new Error("Node require is not defined");
            }
        } catch(e) {
            var fallbackId = window.localStorage.getItem('stashflow_hwid_fallback');
            if (!fallbackId) {
                var chars = '0123456789ABCDEF';
                var randomPart = '';
                for (var i = 0; i < 12; i++) {
                    randomPart += chars[Math.floor(Math.random() * 16)];
                }
                fallbackId = "SF-FALLBACK-" + randomPart;
                window.localStorage.setItem('stashflow_hwid_fallback', fallbackId);
            }
            callback(fallbackId);
        }
    }

    function verifyLicenseOnline(licenseKey, hwid, callback) {
        // Special Beta override key for local/testing use
        if (licenseKey === "StashFlow-BETA-TEST-OVER-RIDE") {
            setTimeout(function() {
                callback(true, null);
            }, 100);
            return;
        }

        // Validate structure: StashFlow-XXXX-XXXX-XXXX-XXXX
        var reg = /^StashFlow-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}$/;
        if (!reg.test(licenseKey)) {
            callback(false, "Invalid license key format.");
            return;
        }

        // Local Cryptographic Node-Locked Verification
        try {
            var salt = "StashFlowBetaSalt2026";
            var str = hwid + salt;
            var hash = 0;
            for (var i = 0; i < str.length; i++) {
                var char = str.charCodeAt(i);
                hash = ((hash << 5) - hash) + char;
                hash = hash & hash;
            }
            var hex = Math.abs(hash).toString(16).toUpperCase();
            while (hex.length < 16) {
                hex += "F";
            }
            var block1 = hex.substring(0, 4);
            var block2 = hex.substring(4, 8);
            var block3 = hex.substring(8, 12);
            var block4 = hex.substring(12, 16);
            
            var expectedKey = "StashFlow-" + block1 + "-" + block2 + "-" + block3 + "-" + block4;
            
            if (licenseKey.toUpperCase() === expectedKey.toUpperCase()) {
                callback(true, null);
            } else {
                callback(false, "Invalid license key for this device.");
            }
        } catch(e) {
            callback(false, "Validation check error: " + e.toString());
        }
    }

    function checkLicenseActivation() {
        getMotherboardHWID(function(hwid) {
            userHwid = hwid;
            var hwidDisplay = document.getElementById('license-hwid-display');
            if (hwidDisplay) hwidDisplay.value = hwid;

            var savedKey = window.localStorage.getItem('stashflow_license_key');
            if (savedKey) {
                verifyLicenseOnline(savedKey, hwid, function(success, errMsg) {
                    if (success) {
                        stashflowActivationToken = "StashFlowSecureTokenPassed_Beta_2026";
                        var actScreen = document.getElementById('activation-screen');
                        if (actScreen) actScreen.classList.add('hidden');
                        init();
                    } else {
                        showActivationUI(errMsg || "Stored license is invalid or expired.");
                    }
                });
            } else {
                showActivationUI("");
            }
        });
    }

    function showActivationUI(message) {
        var loadingScreen = document.getElementById('loading-screen');
        if (loadingScreen) loadingScreen.classList.add('hidden');

        var actScreen = document.getElementById('activation-screen');
        if (actScreen) actScreen.classList.remove('hidden');
        
        var statusDiv = document.getElementById('activation-status');
        if (statusDiv) {
            statusDiv.textContent = message;
            statusDiv.style.color = '#ff3b30';
        }

        var btnActivate = document.getElementById('btn-activate-license');
        var inputKey = document.getElementById('license-key-input');

        btnActivate.onclick = function() {
            var key = (inputKey.value || "").trim();
            if (!key) {
                if (statusDiv) statusDiv.textContent = "Please enter a license key.";
                return;
            }

            if (statusDiv) {
                statusDiv.textContent = "Verifying license...";
                statusDiv.style.color = 'var(--text-secondary)';
            }
            btnActivate.disabled = true;

            verifyLicenseOnline(key, userHwid, function(success, errMsg) {
                btnActivate.disabled = false;
                if (success) {
                    window.localStorage.setItem('stashflow_license_key', key);
                    stashflowActivationToken = "StashFlowSecureTokenPassed_Beta_2026";
                    if (actScreen) actScreen.classList.add('hidden');
                    if (statusDiv) statusDiv.textContent = "";
                    init();
                } else {
                    if (statusDiv) {
                        statusDiv.textContent = errMsg;
                        statusDiv.style.color = '#ff3b30';
                    }
                }
            });
        };
    }

    // Delay license check by 3500ms to allow After Effects to fully load its ExtendScript engine
    setTimeout(checkLicenseActivation, 3500);

    // Panel reopen detection (CEP suspends/resumes panel without reloading JS)
    var lastRefreshTime = 0;
    function onPanelShown() {
        if (!isInitialized) return;
        var now = Date.now();
        if (now - lastStashTime < 5000) {
            logToServer('Suppressing silent scan due to recent stash.');
            return;
        }
        if (now - lastRefreshTime < 2000) return;
        lastRefreshTime = now;
        logToServer('Panel shown event. Re-refreshing gallery (silent).');
        if (libraryPath) refreshCompsList(null, true);
    }

    csInterface.addEventListener('com.adobe.csxs.events.ApplicationActivate', onPanelShown);
    window.addEventListener('focus', onPanelShown);
    document.addEventListener('visibilitychange', function() {
        if (document.visibilityState === 'visible') onPanelShown();
    });

}());
