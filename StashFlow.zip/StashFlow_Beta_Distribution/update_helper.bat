@echo off
title StashFlow Manual Updater
echo ===========================================
echo StashFlow: Updating to v1.13.0...
echo ===========================================
echo.

:: Path to CEP extensions folder
set "DEST_DIR=%APPDATA%\Adobe\CEP\extensions\StashFlow_Beta_Distribution"
set "TMP_ZIP=%TEMP%\StashFlow_temp.zip"

echo Downloading update from GitHub...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/zverren-commits/StashFlow-Releases/main/StashFlow.zip' -OutFile '%TMP_ZIP%' -UseBasicParsing"

if not exist "%TMP_ZIP%" (
    echo.
    echo ERROR: Download failed. Make sure you have uploaded StashFlow.zip to your GitHub repository first.
    goto error
)

echo Extracting files...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force -Path '%TMP_ZIP%' -DestinationPath '%DEST_DIR%'"

echo Cleaning up temp files...
del /f /q "%TMP_ZIP%" >nul 2>&1

echo.
echo ===========================================
echo SUCCESS: StashFlow updated successfully!
echo Please close and restart After Effects.
echo ===========================================
goto end

:error
echo.
echo ===========================================
echo UPDATE FAILED.
echo ===========================================
if exist "%TMP_ZIP%" del /f /q "%TMP_ZIP%"

:end
pause
