const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log("StashFlow Beta Build System starting...");

// Install javascript-obfuscator locally if not present
try {
    require.resolve('javascript-obfuscator');
} catch (e) {
    console.log("Installing javascript-obfuscator...");
    execSync('npm install javascript-obfuscator --no-save', { stdio: 'inherit' });
}

const JavaScriptObfuscator = require('javascript-obfuscator');

const mainJsPath = path.join(__dirname, 'js', 'main.js');
console.log("Reading JS file from:", mainJsPath);
const originalJsCode = fs.readFileSync(mainJsPath, 'utf8');

console.log("Obfuscating JavaScript with high security settings...");
const obfuscationResult = JavaScriptObfuscator.obfuscate(originalJsCode, {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.75,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.4,
    debugProtection: false,
    disableConsoleOutput: false,
    identifierNamesGenerator: 'hexadecimal',
    log: false,
    numbersToExpressions: true,
    renameGlobals: false,
    selfDefending: true,
    simplify: true,
    splitStrings: true,
    splitStringsChunkLength: 10,
    stringArray: true,
    stringArrayCallsTransform: true,
    stringArrayEncoding: ['rc4'],
    stringArrayThreshold: 0.75,
    unicodeEscapeSequence: false
});

console.log("Writing obfuscated JavaScript back...");
fs.writeFileSync(mainJsPath, obfuscationResult.getObfuscatedCode(), 'utf8');
console.log("JavaScript obfuscated successfully!");

console.log("\n==========================================================================");
console.log("IMPORTANT REMINDER FOR EXTENDSCRIPT (.jsxbin):");
console.log("Before building your installer using installer.iss, compile your jsx script:");
console.log("1. Open VS Code and install the 'ExtendScript Debugger' extension.");
console.log("2. Open jsx/hostscript.jsx.");
console.log("3. Right-click in the editor and choose 'Export as Binary' (.jsxbin).");
console.log("4. Save the resulting file as: jsx/hostscript.jsxbin");
console.log("5. Delete jsx/hostscript.jsx to prevent source disclosure.");
console.log("==========================================================================");
