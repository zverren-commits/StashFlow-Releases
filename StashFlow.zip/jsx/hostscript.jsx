// jsx/hostscript.jsx (v56 - Clean rewrite for CEP compatibility)
// NO #target directive - not needed inside CEP ScriptPath context
// NO #include - AE 2018+ has native JSON support

var compBuddyDocDir = new Folder("~/Documents/CompBuddy");
var compBuddyLogDir = new Folder("~/Documents/CompBuddy/logs");
var compBuddySettingsFile = new File("~/Documents/CompBuddy/settings.json");
var logFile = new File("~/Documents/CompBuddy/logs/log.txt");
var logBuffer = [];

function initDirs() {
    try {
        if (!compBuddyDocDir.exists) { compBuddyDocDir.create(); }
        if (!compBuddyLogDir.exists) { compBuddyLogDir.create(); }
        return true;
    } catch (e) {
        return false;
    }
}

function log(msg) {
    try {
        var ts = new Date().toTimeString().substring(0, 8);
        logBuffer.push("[" + ts + "] " + msg);
    } catch (e) {}
}

function writeLogBuffer() {
    try {
        if (logBuffer.length === 0) { return; }
        initDirs();
        logFile.encoding = "UTF-8";
        if (logFile.open("a")) {
            var i;
            for (i = 0; i < logBuffer.length; i++) {
                logFile.writeln(logBuffer[i]);
            }
            logFile.close();
            logBuffer = [];
        }
    } catch (e) {}
}

function clearLogFile() {
    try {
        initDirs();
        logFile.encoding = "UTF-8";
        if (logFile.open("w")) {
            logFile.writeln("--- Log Cleared: " + new Date().toString() + " ---");
            logFile.close();
        }
    } catch (e) {}
}

function renderVideoPreview(comp, targetFile) {
    log("  renderVideoPreview: Rendering video preview to: " + targetFile.fsName);
    var otherItemsStates = [];
    var i;
    for (i = 1; i <= app.project.renderQueue.numItems; i++) {
        var item = app.project.renderQueue.item(i);
        otherItemsStates.push({ item: item, render: item.render });
        try {
            item.render = false;
        } catch(err) {}
    }
    var rqItem = null;
    try {
        rqItem = app.project.renderQueue.items.add(comp);
        var renderDuration = Math.min(2.0, comp.duration);
        rqItem.timeSpanStart = 0;
        rqItem.timeSpanDuration = renderDuration;
        var om = rqItem.outputModule(1);
        
        // Find H.264 template dynamically
        var templates = om.templates;
        var h264Template = null;
        var ti;
        for (ti = 0; ti < templates.length; ti++) {
            if (templates[ti].toLowerCase().indexOf("h.264") !== -1 || templates[ti].toLowerCase().indexOf("h264") !== -1) {
                h264Template = templates[ti];
                break;
            }
        }
        if (h264Template) {
            try {
                om.applyTemplate(h264Template);
            } catch(e) {}
        } else {
            log("  renderVideoPreview: WARNING - H.264 template not found, searching for High Quality.");
            var hqTemplate = null;
            var tj;
            for (tj = 0; tj < templates.length; tj++) {
                if (templates[tj].toLowerCase().indexOf("high quality") !== -1) {
                    hqTemplate = templates[tj];
                    break;
                }
            }
            if (hqTemplate) {
                try {
                    om.applyTemplate(hqTemplate);
                } catch(e) {}
            }
        }
        om.file = targetFile;
        log("    renderVideoPreview: Rendering via Render Queue...");
        app.project.renderQueue.render();
        log("    renderVideoPreview: Render complete.");
        return targetFile.exists;
    } catch(e) {
        log("    renderVideoPreview: EXCEPTION - " + e.toString());
        return false;
    } finally {
        var ri;
        for (ri = 0; ri < otherItemsStates.length; ri++) {
            try {
                otherItemsStates[ri].item.render = otherItemsStates[ri].render;
            } catch (err) {}
        }
        if (rqItem) {
            try { rqItem.remove(); } catch(err) {}
        }
    }
}

// Read JSON from file safely
function safeReadJSON(file) {
    var content = null;
    var parsed = null;
    try {
        log("  safeReadJSON: " + (file ? file.fsName : "null"));
        if (!file || !file.exists) {
            log("  safeReadJSON: missing");
            return null;
        }
        if (!file.open("r")) {
            log("  safeReadJSON: open failed");
            return null;
        }
        file.encoding = "UTF-8";
        if (file.length > 0) {
            content = file.read();
        } else {
            log("  safeReadJSON: empty");
            file.close();
            return null;
        }
        file.close();
        // Remove UTF-8 BOM if present
        if (content && content.charCodeAt(0) === 0xFEFF) {
            content = content.substring(1);
        }
        // Trim whitespace manually to avoid regex issues
        content = content.replace(/^\s+/, "").replace(/\s+$/, "");
        // Basic check: must start with { and end with }
        if (content.charAt(0) !== "{" || content.charAt(content.length - 1) !== "}") {
            log("  safeReadJSON: not JSON object");
            return null;
        }
        parsed = JSON.parse(content);
        log("  safeReadJSON: OK");
        return parsed;
    } catch (e) {
        log("  safeReadJSON ERROR: " + e.toString());
        try { file.close(); } catch (e2) {}
        return null;
    }
}

// Write JSON to file safely
function safeWriteJSON(file, obj) {
    try {
        log("  safeWriteJSON: " + (file ? file.fsName : "null"));
        if (!file || !obj) { return false; }
        if (!file.parent.exists) { file.parent.create(); }
        var jsonStr = JSON.stringify(obj, null, 2);
        if (!jsonStr) { return false; }
        if (!file.open("w")) { return false; }
        file.encoding = "UTF-8";
        file.lineFeed = "unix";
        var ok = file.write(jsonStr);
        file.close();
        return ok;
    } catch (e) {
        log("  safeWriteJSON ERROR: " + e.toString());
        try { file.close(); } catch (e2) {}
        return false;
    }
}

// --- Config Functions ---

function getLibraryPathFromConfigCEP() {
    try {
        if (compBuddySettingsFile.exists) {
            var settings = safeReadJSON(compBuddySettingsFile);
            if (settings && settings.libraryPath) {
                return settings.libraryPath;
            }
        }
    } catch (e) {}
    return "";
}

function saveLibraryPathToConfigCEP(newPath) {
    try {
        var settings = {};
        if (compBuddySettingsFile.exists) {
            var existing = safeReadJSON(compBuddySettingsFile);
            if (existing) { settings = existing; }
        }
        settings.libraryPath = newPath;
        initDirs();
        safeWriteJSON(compBuddySettingsFile, settings);
        log("Saved library path: " + newPath);
        writeLogBuffer();
        return JSON.stringify({ success: true });
    } catch (e) {
        log("saveLibraryPathToConfigCEP ERROR: " + e.toString());
        writeLogBuffer();
        return JSON.stringify({ success: false, message: e.toString() });
    }
}

function checkAndConfirmFolderPathCEP(folderPath) {
    log("checkAndConfirmFolderPathCEP: " + folderPath);
    var result = { exists: false, confirmedPath: null, error: null };
    try {
        if (!folderPath || typeof folderPath !== "string") {
            result.error = "Invalid path";
        } else {
            var f = new Folder(folderPath);
            if (f.exists && f instanceof Folder) {
                result.exists = true;
                result.confirmedPath = f.fsName;
                log("Folder exists: " + result.confirmedPath);
            } else {
                result.error = "Not a valid folder";
                result.confirmedPath = folderPath;
            }
        }
    } catch (e) {
        result.error = e.toString();
        result.confirmedPath = folderPath;
    }
    writeLogBuffer();
    return JSON.stringify(result);
}

function selectLibraryFolderCEP() {
    log("selectLibraryFolderCEP called");
    try {
        var folder = Folder.selectDialog("Select your StashFlow Library Folder");
        if (folder instanceof Folder) {
            log("Selected: " + folder.fsName);
            return folder.fsName;
        }
    } catch (e) {
        log("selectLibraryFolderCEP ERROR: " + e.toString());
    }
    return null;
}

// --- Scan Library ---

function getStashedCompsCEP(libraryPath) {
    log("---- Scan v56 START ----");
    var compsData = [];
    var allFoundCategories = [];
    var finalJson = "{}";
    try {
        if (!libraryPath || typeof libraryPath !== "string") {
            throw new Error("Invalid library path");
        }
        log("Scanning: " + libraryPath);
        var mainFolder = new Folder(libraryPath);
        if (!mainFolder.exists || !(mainFolder instanceof Folder)) {
            throw new Error("Library folder not found");
        }
        var catFolders = mainFolder.getFiles(function(f) { return f instanceof Folder; });
        log("Categories: " + (catFolders ? catFolders.length : 0));
        if (catFolders && catFolders.length > 0) {
            var i, j, k;
            for (i = 0; i < catFolders.length; i++) {
                var catFolder = catFolders[i];
                if (!(catFolder instanceof Folder)) { continue; }
                var catName = decodeURI(catFolder.name);
                allFoundCategories.push(catName);
                log("Category: " + catName);
                var compFolders = catFolder.getFiles(function(f) { return f instanceof Folder; });
                if (!compFolders || compFolders.length === 0) { continue; }
                for (j = 0; j < compFolders.length; j++) {
                    var compFolder = compFolders[j];
                    if (!(compFolder instanceof Folder)) { continue; }
                    var aepFiles = compFolder.getFiles("*.aep");
                    if (!aepFiles || aepFiles.length === 0) { continue; }
                    var aepFile = aepFiles[0];
                    if (!(aepFile instanceof File)) { continue; }
                    var thumbFile = new File(compFolder.fullName + "/comp.png");
                    var mp4File = new File(compFolder.fullName + "/preview.mp4");
                    var metaFile = new File(compFolder.fullName + "/metadata.json");
                    var compData = {
                        name: decodeURI(compFolder.name),
                        category: catName,
                        uniqueId: compFolder.name,
                        aepPath: aepFile.fsName,
                        thumbPath: (thumbFile && thumbFile.exists) ? thumbFile.fsName : null,
                        mp4Path: (mp4File && mp4File.exists) ? mp4File.fsName : null,
                        width: null,
                        height: null,
                        previewFrames: []
                    };
                    if (metaFile.exists) {
                        var meta = safeReadJSON(metaFile);
                        if (meta) {
                            compData.name = meta.displayName || compData.name;
                            compData.width = meta.width || null;
                            compData.height = meta.height || null;
                            compData.previewFPS = meta.previewFPS || 12;
                        }
                    }
                    
                    // Dynamically scan compFolder for all preview_*.png files
                    var folderFiles = compFolder.getFiles();
                    var tempFrames = [];
                    var fk;
                    for (fk = 0; fk < folderFiles.length; fk++) {
                        var file = folderFiles[fk];
                        if (file instanceof File && (file.name.indexOf("preview_") === 0 || file.name.indexOf("frame_") === 0) && file.name.toLowerCase().indexOf(".png") !== -1) {
                            tempFrames.push(file);
                        }
                    }
                    
                    // Sort numerically based on the number in "preview_X.png"
                    tempFrames.sort(function(a, b) {
                        try {
                            var numA = parseInt(a.name.match(/\d+/)[0], 10);
                            var numB = parseInt(b.name.match(/\d+/)[0], 10);
                            return numA - numB;
                        } catch(e) {
                            return 0;
                        }
                    });
                    
                    for (fk = 0; fk < tempFrames.length; fk++) {
                        compData.previewFrames.push(tempFrames[fk].fsName);
                    }
                    
                    if (compData.previewFrames.length === 0 && thumbFile.exists) {
                        compData.previewFrames.push(thumbFile.fsName);
                    }
                    compsData.push(compData);
                }
            }
        }
        log("Scan done. Found: " + compsData.length + " templates, " + allFoundCategories.length + " categories.");
        var responseObj = {
            templates: compsData,
            categories: allFoundCategories
        };
        finalJson = JSON.stringify(responseObj);
        log("JSON length: " + finalJson.length);
    } catch (e) {
        var errMsg = "Scan error: " + e.toString();
        log(errMsg);
        writeLogBuffer();
        return JSON.stringify({ error: errMsg });
    }
    log("---- Scan v56 END ----");
    writeLogBuffer();
    return finalJson;
}

// --- Stash Function Helper: Get active comp duration ---
function getActiveCompDurationCEP() {
    try {
        log("---- getActiveCompDurationCEP START ----");
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            log("getActiveCompDurationCEP: No active comp.");
            writeLogBuffer();
            return JSON.stringify({ success: false, message: "No active composition." });
        }
        log("getActiveCompDurationCEP: Found comp name=" + comp.name + " dur=" + comp.duration + " time=" + comp.time + " fps=" + comp.frameRate);
        writeLogBuffer();
        return JSON.stringify({
            success: true,
            duration: comp.duration,
            time: comp.time,
            frameRate: comp.frameRate,
            name: comp.name
        });
    } catch(e) {
        log("getActiveCompDurationCEP EXCEPTION: " + e.toString());
        writeLogBuffer();
        return JSON.stringify({ success: false, message: e.toString() });
    }
}

// --- Stash Function Helper: Sync current playhead time ---
function syncPlayheadTimeCEP(val) {
    try {
        var comp = app.project.activeItem;
        if (comp && comp instanceof CompItem) {
            comp.time = parseFloat(val);
        }
        return "true";
    } catch(e) {
        return "false";
    }
}

// --- Stash Function Helper: Save temporary frame for scrubbing ---
function saveTempFrameCEP(opts) {
    try {
        var time = parseFloat(opts.time);
        var cacheFolder = opts.cacheFolder;
        var suffix = opts.suffix || 'a';
        log("---- saveTempFrameCEP START ---- time=" + time + " cache=" + cacheFolder + " suffix=" + suffix);
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            log("saveTempFrameCEP: No active comp.");
            writeLogBuffer();
            return JSON.stringify({ success: false, message: "No active composition." });
        }
        var originalTime = comp.time;
        
        // Save to extension's local cache folder
        var folderObj = new Folder(cacheFolder);
        if (!folderObj.exists) folderObj.create();
        var tempFile = new File(folderObj.fullName + "/ae_stash_preview_" + suffix + ".png");
        if (tempFile.exists) {
            try { tempFile.remove(); } catch(ex) {}
        }
        
        try {
            comp.openInViewer();
        } catch(ex) {}
        
        comp.time = time;
        $.sleep(120); // wait for AE to render the frame in the viewer
        comp.saveFrameToPng(time, tempFile);
        
        // Wait for file creation safely
        var waitCount = 0;
        while (!tempFile.exists && waitCount < 50) {
            $.sleep(10);
            waitCount++;
        }
        
        // Restore time
        try { comp.time = originalTime; } catch(ex) {}
        
        if (tempFile.exists) {
            log("saveTempFrameCEP: Successfully rendered frame at path=" + tempFile.fsName);
            writeLogBuffer();
            return JSON.stringify({ success: true, suffix: suffix });
        } else {
            log("saveTempFrameCEP: Temporary file was not created.");
            writeLogBuffer();
            return JSON.stringify({ success: false, message: "Could not save temporary frame." });
        }
    } catch(e) {
        log("saveTempFrameCEP EXCEPTION: " + e.toString());
        writeLogBuffer();
        return JSON.stringify({ success: false, message: e.toString() });
    }
}

// --- Stash Function ---
function stashSelectedCompCEP(opts) {
    var libraryPath = opts.libraryPath;
    var categoryName = decodeURIComponent(opts.categoryName);
    log("---- Stash v56 START ---- cat=" + categoryName);
    var originalProject = app.project;
    var originalProjectFile = originalProject ? originalProject.file : null;
    var tempBackup = null;
    var secretTemp = null;
    var compName = "";
    try {
        if (!originalProject) { throw new Error("No project open."); }
        var selected = originalProject.selection;
        if (!selected || selected.length !== 1 || !(selected[0] instanceof CompItem)) {
            throw new Error("Select exactly one composition.");
        }
        var comp = selected[0];
        var compId = comp.id;
        compName = comp.name;
        var compW = comp.width;
        var compH = comp.height;
        var safeCompName = compName.replace(/[^a-z0-9]/gi, "_").replace(/__+/g, "_");
        if (!originalProjectFile) {
            tempBackup = new File(Folder.temp.fullName + "/sb_unsaved_" + new Date().getTime() + ".aep");
            originalProject.save(tempBackup);
            originalProjectFile = tempBackup;
        }
        var catFolder = new Folder(libraryPath + "/" + categoryName);
        if (!catFolder.exists && !catFolder.create()) {
            throw new Error("Could not create category folder");
        }
        var compFolderPath = catFolder.fullName + "/" + safeCompName;
        var compFolder = new Folder(compFolderPath);
        if (compFolder.exists) {
            var oldFiles = compFolder.getFiles();
            var xi;
            for (xi = 0; xi < oldFiles.length; xi++) {
                if (oldFiles[xi] instanceof File) {
                    try { oldFiles[xi].remove(); } catch (ex) {}
                }
            }
        } else {
            compFolder.create();
        }
        // === Instant Transparent PNG Sequence Rendering via saveFrameToPng ===
        var previewFPS = 12;
        var rangeStart, rangeEnd, staticTime;
        
        if (opts.rangeStart !== undefined && opts.rangeStart !== null) {
            // Manual Preview selected from sliders
            rangeStart = parseFloat(opts.rangeStart);
            rangeEnd = parseFloat(opts.rangeEnd);
            staticTime = parseFloat(opts.staticTime);
        } else {
            // Auto Preview: calculate midpoint and 3-second window
            var mid = comp.duration / 2;
            staticTime = mid;
            rangeStart = mid - 1.5;
            rangeEnd = mid + 1.5;
        }
        
        // Safety clamps
        if (rangeStart < 0) rangeStart = 0;
        if (rangeEnd > comp.duration) rangeEnd = comp.duration;
        if (staticTime < 0) staticTime = 0;
        if (staticTime > comp.duration) staticTime = comp.duration;
        
        var renderDur = rangeEnd - rangeStart;
        var captureCount = 18; // 18 frames total (between 12 and 20 frames total) for fast low-res exports
        var relativeFrames = [];
        
        var originalTime = comp.time;
        var oldROI = comp.regionOfInterest;
        
        try {
            comp.regionOfInterest = [0, 0, compW, compH];
        } catch(e) {}
        
        try {
            comp.openInViewer();
        } catch(e) {}
        
        var qi;
        for (qi = 0; qi < captureCount; qi++) {
            var t = (captureCount <= 1) ? rangeStart : (rangeStart + (renderDur * qi / (captureCount - 1)));
            if (t < 0) t = 0;
            if (t > comp.duration) t = comp.duration;
            
            var frameName = "frame_" + qi + ".png";
            var frameFile = new File(compFolder.fullName + "/" + frameName);
            try {
                comp.time = t;
                $.sleep(120); // wait for AE to render the frame in the viewer
                comp.saveFrameToPng(t, frameFile);
                relativeFrames.push(frameName); // Always write to metadata list immediately
            } catch(e) {
                log("saveFrameToPng failed at " + t + "s: " + e.toString());
            }
        }
        
        // Thumbnail png frame (rendered directly from selected staticTime)
        var thumbFile = new File(compFolder.fullName + "/comp.png");
        try {
            comp.time = staticTime;
            $.sleep(120);
            comp.saveFrameToPng(staticTime, thumbFile);
            log("Rendered static thumbnail directly from staticTime: " + staticTime + "s");
        } catch(e) {
            log("Static thumbnail rendering failed: " + e.toString());
        }
        
        // Restore comp settings
        try {
            comp.time = originalTime;
            comp.regionOfInterest = oldROI;
        } catch(e) {}
        
        // === Write metadata ===
        var metaFile = new File(compFolder.fsName + "/metadata.json");
        safeWriteJSON(metaFile, {
            displayName: compName,
            width: compW,
            height: compH,
            previewFPS: previewFPS,
            previewFrames: relativeFrames
        });
        // === Save AEP ===
        var ts = new Date().getTime();
        app.beginUndoGroup("StashFlow Stash");
        secretTemp = new File(Folder.temp.fullName + "/sb_secret_" + ts + ".aep");
        app.project.save(secretTemp);
        var targetComp = null;
        var si;
        for (si = 1; si <= app.project.numItems; si++) {
            try {
                if (app.project.item(si).id === compId) {
                    targetComp = app.project.item(si);
                    break;
                }
            } catch (ie) {}
        }
        if (!targetComp) {
            for (si = 1; si <= app.project.numItems; si++) {
                try {
                    if (app.project.item(si).name === compName && app.project.item(si) instanceof CompItem) {
                        targetComp = app.project.item(si);
                        break;
                    }
                } catch (ie) {}
            }
        }
        if (!targetComp) { throw new Error("Could not find comp in temp project"); }
        app.project.reduceProject([targetComp]);
        var footageDir = new Folder(compFolder.fullName + "/(Footage)");
        footageDir.create();
        var fi;
        for (fi = 1; fi <= app.project.numItems; fi++) {
            try {
                var item = app.project.item(fi);
                if (item instanceof FootageItem && item.mainSource && item.mainSource.file) {
                    var src = item.mainSource.file;
                    var isAdobe = (src.fsName.indexOf("Adobe") !== -1 && src.fsName.indexOf("After Effects") !== -1);
                    if (!isAdobe) {
                        var dest = new File(footageDir.fullName + "/" + src.name);
                        if (!dest.exists) { src.copy(dest); }
                        item.replace(dest);
                    }
                }
            } catch (fe) {}
        }
        // Clear all items from the temp project's render queue before saving to ensure clean import
        while (app.project.renderQueue.numItems > 0) {
            try {
                app.project.renderQueue.item(1).remove();
            } catch(re) {
                break;
            }
        }
        app.project.save(secretTemp);
        var finalAEP = new File(compFolder.fullName + "/" + safeCompName + ".aep");
        secretTemp.copy(finalAEP);
        app.endUndoGroup();
        log("Stash OK: " + compName);
    } catch (e) {
        log("Stash ERROR: " + e.toString());
        try { app.endUndoGroup(); } catch (eg) {}
        try {
            if (originalProjectFile && originalProjectFile.exists) { app.open(originalProjectFile); }
            if (secretTemp && secretTemp.exists) { secretTemp.remove(); }
            if (tempBackup && tempBackup.exists) { tempBackup.remove(); }
        } catch (ce) {}
        writeLogBuffer();
        return JSON.stringify({ success: false, message: "Stash Error: " + e.toString() });
    }
    try {
        if (originalProjectFile && originalProjectFile.exists) { app.open(originalProjectFile); }
        if (secretTemp && secretTemp.exists) { secretTemp.remove(); }
        if (tempBackup && tempBackup.exists) { tempBackup.remove(); }
    } catch (ce) {}
    writeLogBuffer();
    return JSON.stringify({ success: true, message: "Stashed: " + compName });
}

// --- Import Function ---

function importCompCEP(aepPath) {
    log("importCompCEP: " + aepPath);
    try {
        if (!app.project) { app.newProject(); }
        var f = new File(aepPath);
        if (!f.exists) {
            writeLogBuffer();
            return JSON.stringify({ success: false, message: "AEP not found: " + aepPath });
        }
        app.beginUndoGroup("StashFlow Import");
        var opts = new ImportOptions(f);
        var imported = app.project.importFile(opts);
        var finalName = decodeURI(f.name.replace(".aep", ""));
        var metaFile = new File(f.parent.fullName + "/metadata.json");
        if (metaFile.exists) {
            var meta = safeReadJSON(metaFile);
            if (meta && meta.displayName) { finalName = meta.displayName; }
        }
        try {
            if (imported) { imported.name = finalName + " [StashFlow]"; }
        } catch (re) {}
        app.endUndoGroup();
        writeLogBuffer();
        return JSON.stringify({ success: true, message: "Imported: " + finalName });
    } catch (e) {
        log("importCompCEP ERROR: " + e.toString());
        try { app.endUndoGroup(); } catch (eg) {}
        writeLogBuffer();
        return JSON.stringify({ success: false, message: "Import Error: " + e.toString() });
    }
}

// --- Delete Function ---

function deleteFolderRecursive(folder) {
    if (!folder || !folder.exists) return;
    var files = folder.getFiles();
    var i;
    for (i = 0; i < files.length; i++) {
        if (files[i] instanceof Folder) {
            deleteFolderRecursive(files[i]);
        } else {
            try { files[i].remove(); } catch(e) {}
        }
    }
    try { folder.remove(); } catch(e) {}
}

function deleteStashedCompCEP(opts) {
    var libraryPath = opts.libraryPath;
    var category = decodeURIComponent(opts.category);
    var uniqueId = opts.uniqueId;
    log("deleteStashedCompCEP: cat=" + category + " id=" + uniqueId);
    try {
        var compFolder = new Folder(libraryPath + "/" + category + "/" + uniqueId);
        if (!compFolder.exists) {
            writeLogBuffer();
            return JSON.stringify({ success: false, message: "Folder not found" });
        }
        deleteFolderRecursive(compFolder);
        log("Deleted: " + uniqueId);
        writeLogBuffer();
        return JSON.stringify({ success: true, message: "Deleted: " + uniqueId });
    } catch (e) {
        log("deleteStashedCompCEP ERROR: " + e.toString());
        writeLogBuffer();
        return JSON.stringify({ success: false, message: "Delete Error: " + e.toString() });
    }
}

// --- Create Category Function ---

function createCategoryCEP(opts) {
    var libraryPath = opts.libraryPath;
    var categoryName = decodeURIComponent(opts.categoryName);
    log("createCategoryCEP: " + categoryName);
    if (!libraryPath || typeof libraryPath !== "string") {
        writeLogBuffer();
        return JSON.stringify({ success: false, message: "Invalid library path" });
    }
    try {
        var safeName = categoryName;
        // Remove forbidden chars without regex to avoid potential issues
        var forbidden = ["<", ">", ":", "\"", "/", "\\", "|", "?", "*"];
        var ci;
        for (ci = 0; ci < forbidden.length; ci++) {
            while (safeName.indexOf(forbidden[ci]) !== -1) {
                safeName = safeName.replace(forbidden[ci], "");
            }
        }
        safeName = safeName.replace(/^\s+|\s+$/, "");
        if (!safeName) {
            writeLogBuffer();
            return JSON.stringify({ success: false, message: "Invalid category name" });
        }
        var folder = new Folder(libraryPath + "/" + safeName);
        if (!folder.exists) {
            if (!folder.create()) {
                writeLogBuffer();
                return JSON.stringify({ success: false, message: "Could not create folder" });
            }
        }
        log("Category ready: " + safeName);
        writeLogBuffer();
        return JSON.stringify({ success: true, categoryName: safeName });
    } catch (e) {
        log("createCategoryCEP ERROR: " + e.toString());
        writeLogBuffer();
        return JSON.stringify({ success: false, message: "Error: " + e.toString() });
    }
}

// --- Open Folder Function ---

function openFolderCEP(folderPath) {
    log("openFolderCEP: " + folderPath);
    try {
        var f = new Folder(folderPath);
        if (f.exists && f instanceof Folder) {
            f.execute();
            writeLogBuffer();
            return JSON.stringify({ success: true });
        }
        writeLogBuffer();
        return JSON.stringify({ success: false, message: "Folder not found" });
    } catch (e) {
        log("openFolderCEP ERROR: " + e.toString());
        writeLogBuffer();
        return JSON.stringify({ success: false, message: e.toString() });
    }
}

// --- Rename Stashed Comp Function ---
function renameStashedCompCEP(opts) {
    var libraryPath = opts.libraryPath;
    var category = decodeURIComponent(opts.category);
    var uniqueId = opts.uniqueId;
    var newName = opts.newName;
    log("---- renameStashedCompCEP START ---- uniqueId=" + uniqueId + " newName=" + newName);
    try {
        var compFolder = new Folder(libraryPath + "/" + category + "/" + uniqueId);
        if (!compFolder.exists) {
            throw new Error("Template folder not found: " + compFolder.fsName);
        }
        var metaFile = new File(compFolder.fullName + "/metadata.json");
        var meta = {};
        if (metaFile.exists) {
            var existing = safeReadJSON(metaFile);
            if (existing) {
                meta = existing;
            }
        }
        meta.displayName = newName;
        safeWriteJSON(metaFile, meta);
        log("Renamed template successfully to: " + newName);
        writeLogBuffer();
        return JSON.stringify({ success: true });
    } catch (e) {
        log("renameStashedCompCEP ERROR: " + e.toString());
        writeLogBuffer();
        return JSON.stringify({ success: false, message: e.toString() });
    }
}

// --- Category Deletion Functions ---
function deleteFolderRecursive(folder) {
    if (!folder.exists) return true;
    var files = folder.getFiles();
    var i;
    for (i = 0; i < files.length; i++) {
        var file = files[i];
        if (file instanceof Folder) {
            deleteFolderRecursive(file);
        } else {
            file.remove();
        }
    }
    return folder.remove();
}

function deleteCategoryCEP(opts) {
    var libraryPath = opts.libraryPath;
    var categoryName = decodeURIComponent(opts.categoryName);
    log("---- deleteCategoryCEP START ---- cat=" + categoryName);
    try {
        var catFolder = new Folder(libraryPath + "/" + categoryName);
        if (catFolder.exists) {
            var success = deleteFolderRecursive(catFolder);
            if (success) {
                log("Deleted folder successfully: " + catFolder.fsName);
                writeLogBuffer();
                return JSON.stringify({ success: true });
            } else {
                throw new Error("Failed to delete some files or the folder itself.");
            }
        }
        writeLogBuffer();
        return JSON.stringify({ success: false, message: "Category folder does not exist." });
    } catch (e) {
        log("deleteCategoryCEP ERROR: " + e.toString());
        writeLogBuffer();
        return JSON.stringify({ success: false, message: e.toString() });
    }
}

function _isSafeUpdateUrl(url) {
    // Whitelist your domain and GitHub/raw.githubusercontent.com for secure releases
    return /^https:\/\/([A-Za-z0-9\-]+\.)?(your-domain\.com|github\.com|raw\.githubusercontent\.com)\/.*\.zip$/.test(url);
}

function installExtensionUpdate(url) {
    try {
        log("installExtensionUpdate: starting download for URL: " + url);
        if (!_isSafeUpdateUrl(url)) {
            log("installExtensionUpdate ERROR: URL rejected by safety policy");
            return JSON.stringify({ success: false, error: "Update URL rejected by safety policy." });
        }
        
        // Determine target install directory in user AppData (always writeable, overrides Program Files in CEP)
        var targetFolder = new Folder(Folder.userData.fullName + "/Adobe/CEP/extensions/StashFlow_Beta_Distribution");
        if (!targetFolder.exists) {
            var parent1 = new Folder(Folder.userData.fullName + "/Adobe");
            if (!parent1.exists) parent1.create();
            var parent2 = new Folder(Folder.userData.fullName + "/Adobe/CEP");
            if (!parent2.exists) parent2.create();
            var parent3 = new Folder(Folder.userData.fullName + "/Adobe/CEP/extensions");
            if (!parent3.exists) parent3.create();
            targetFolder.create();
        }
        var extDir = targetFolder.fsName;
        var tmpZip;
        
        if ($.os.indexOf("Mac") >= 0) {
            tmpZip = "/tmp/stashflow_update.zip";
            
            // Download zip
            system.callSystem('curl -sL --max-time 300 -o "' + tmpZip + '" "' + url + '"');
            var f = new File(tmpZip);
            if (!f.exists || f.length < 1024) {
                log("installExtensionUpdate ERROR: Mac download failed or zip empty");
                try { f.remove(); } catch(e) {}
                return JSON.stringify({ success: false, error: "Download failed." });
            }
            
            // Extract
            system.callSystem('unzip -o "' + tmpZip + '" -d "' + extDir + '"');
            system.callSystem('rm -f "' + tmpZip + '"');
        } else {
            tmpZip = $.getenv("TEMP") + "\\\\stashflow_update.zip";
            
            // Pre-clean old temp zip if exists
            var wf = new File(tmpZip);
            if (wf.exists) {
                try { wf.remove(); } catch(ex) {}
            }
            
            var cmd = 'powershell -NoProfile -ExecutionPolicy Bypass -Command "';
            cmd += "try { ";
            cmd += "  Invoke-WebRequest -Uri '" + url + "' -OutFile '" + tmpZip + "' -TimeoutSec 300 -UseBasicParsing; ";
            cmd += "  Expand-Archive -Force -Path '" + tmpZip + "' -DestinationPath '" + extDir + "'; ";
            cmd += "  Remove-Item '" + tmpZip + "'; ";
            cmd += "  exit 0 ";
            cmd += "} catch { ";
            // Do NOT remove the zip file in catch so that the JSX script sees wf.exists is true and handles it as a failure
            cmd += "  exit 1 ";
            cmd += "}";
            cmd += '"';
            
            log("installExtensionUpdate: calling shell command on Windows");
            var shellResult = system.callSystem('cmd /c ' + cmd);
            log("installExtensionUpdate: Windows shell completed: " + shellResult);
            
            if (wf.exists) {
                try { wf.remove(); } catch(e) {}
                log("installExtensionUpdate ERROR: Windows install failed");
                return JSON.stringify({ success: false, error: "Installation failed." });
            }
        }
        
        log("installExtensionUpdate: update installed successfully!");
        writeLogBuffer();
        return JSON.stringify({ success: true });
    } catch (e) {
        log("installExtensionUpdate EXCEPTION: " + e.toString());
        writeLogBuffer();
        return JSON.stringify({ success: false, error: e.toString() });
    }
}

log("hostscript.jsx v56 loaded OK.");
writeLogBuffer();